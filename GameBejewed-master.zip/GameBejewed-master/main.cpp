
#include "game.h"

int main(int argv, char** args) {
   Game game;
   game.game_main();
   return 0;
}
